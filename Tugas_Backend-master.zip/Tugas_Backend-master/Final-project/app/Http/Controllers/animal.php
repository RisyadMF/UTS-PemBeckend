<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class animal extends Controller
{

    function index(){
        echo "menampilkan";
    }
}
